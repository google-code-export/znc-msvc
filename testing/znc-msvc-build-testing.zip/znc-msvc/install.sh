#!/bin/sh
echo 'This file is actually *not* needed, but autocrap wants it'
