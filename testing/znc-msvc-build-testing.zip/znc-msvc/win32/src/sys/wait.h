#ifndef _WIN32_SYS_WAIT_H
#define _WIN32_SYS_WAIT_H

#include <znc_msvc.h>

#endif // _WIN32_SYS_WAIT_H