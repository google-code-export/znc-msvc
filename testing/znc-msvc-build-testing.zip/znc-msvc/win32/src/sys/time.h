#ifndef _WIN32_SYS_TIME_H
#define _WIN32_SYS_TIME_H

#include <znc_msvc.h>

#endif // _WIN32_SYS_TIME_H