#ifndef _WIN32_SYS_FILE_H
#define _WIN32_SYS_FILE_H

#include <znc_msvc.h>
#include <sys/fcntl.h>

#endif // _WIN32_SYS_FILE_H