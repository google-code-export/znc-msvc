#ifndef _WIN32_UNISTD_H
#define _WIN32_UNISTD_H

#include <znc_msvc.h>

 /* access */
 #define F_OK    0
 #define X_OK    1
 #define W_OK    2
 #define R_OK    4

#endif // _WIN32_UNISTD_H