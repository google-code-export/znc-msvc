#ifndef _WIN32_PWD_H
#define _WIN32_PWD_H

#include <znc_msvc.h>

#endif // _WIN32_PWD_H