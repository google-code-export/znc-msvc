Some explanation:

The contents of this archive need to go into ZNC\win32.


The c-ares folder is for c-ares, obviously, can be downloaded from:
http://c-ares.haxx.se/daily-snapshot/
c-ares has its own MSVC project files, you can use those.


The msvc folder holds the solution file
and the project file for ZNC.dll.

znc_bootstrap has the project file for ZNC.exe (cli).

znc_service contains the project file for znc_service.exe
and the mc file for service_provider.dll.


Don't forget to download & build OpenSSL as well!
http://www.openssl.org/

Also you will obviously have to adjust the include and lib paths to
match your OpenSSL directories (look for stuff like TrillShared\lib and _myinclude).


Good Luck!

